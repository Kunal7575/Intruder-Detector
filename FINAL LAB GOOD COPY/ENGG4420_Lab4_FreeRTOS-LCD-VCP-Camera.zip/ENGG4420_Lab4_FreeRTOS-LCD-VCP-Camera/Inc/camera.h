/*
 * camera.h
 *
 *  Created on: Nov 3, 2018
 *      Author: Proj_Admin
 */



#ifndef CAMERA_H_
#define CAMERA_H_




void camera_setup();
void camera_initiate_capture();


#endif /* CAMERA_H_ */
