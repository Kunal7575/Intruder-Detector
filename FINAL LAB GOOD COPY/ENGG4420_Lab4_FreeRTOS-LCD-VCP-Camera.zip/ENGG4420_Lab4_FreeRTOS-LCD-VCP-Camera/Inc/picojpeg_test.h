#ifndef __dmaarouf_picojpeg_test_H
#define __dmaarouf_picojpeg_test_H
#ifdef __cplusplus
 extern "C" {
#endif

int picojpg_test(FILE * pic_stream, int * width, int * height, int * comps, uint8_t * bitmap);

#ifdef __cplusplus
}
#endif
#endif /*__ __dmaarouf_picojpeg_test_H */
